For the eighthr dataset to run it needs to be in the same directoory as preprocess.py and main.py
to run:

    python3 main.py perceptron digits
    python3 main.py svm_l digits
    python3 main.py svm_nl digits
    python3 main.py dt_gini digits
    python3 main.py dt_entropy digits
    python3 main.py knn_minkowski digits
    python3 main.py knn_euclidean digits
    python3 main.py knn_manhattan digits

    python3 main.py perceptron eighthr
    python3 main.py svm_l eighthr
    python3 main.py svm_nl eighthr
    python3 main.py dt_gini eighthr
    python3 main.py dt_entropy eighthr
    python3 main.py knn_minkowski eighthr
    python3 main.py knn_euclidean eighthr
    python3 main.py knn_manhattan eighthr
    