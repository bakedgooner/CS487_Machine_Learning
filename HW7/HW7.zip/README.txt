

To run:

    python3 main.py iris kmeans
    python3 main.py iris sci_hei
    python3 main.py iris skl_hei
    python3 main.py iris dbscan
    python3 main.py faulty kmeans
    python3 main.py faulty sci_hei
    python3 main.py faulty skl_hei
    python3 main.py faulty dbscan
