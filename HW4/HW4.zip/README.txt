to run mammagraphic dataset must be in same directory as main.py:

    python3 main.py decisiontree digits
    python3 main.py randforest digits
    python3 main.py bagging digits
    python3 main.py adaboost digits

    python3 main.py decisiontree mammographic_masses.data
    python3 main.py randforest mammographic_masses.data
    python3 main.py bagging mammographic_masses.data
    python3 main.py adaboost mammographic_masses.data
    