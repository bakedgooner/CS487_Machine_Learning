This program is meant to be run on a dataset where the last column is the class column
To run the the program the dataset must be in the same directory as HW2.py

    python3 HW2.py perceptron iris.data
    python3 HW2.py adaline iris.data
    python3 HW2.py sgd iris.data

    python3 HW2.py perceptron ionosphere.data
    python3 HW2.py adaline ionosphere.data
    python3 HW2.py sgd ionosphere.data   