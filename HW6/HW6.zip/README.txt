to run:

    python3 main.py housing lin_reg
    python3 main.py housing ransac
    python3 main.py housing ridge
    python3 main.py housing lasso
    python3 main.py housing norm_eq
    python3 main.py housing svr
    python3 main.py CRP lin_reg
    python3 main.py CRP ransac
    python3 main.py CRP ridge
    python3 main.py CRP lasso
    python3 main.py CRP svr