to run:

    python3 main.py iris PCA
    python3 main.py iris LDA
    python3 main.py iris Kernel_PCA
    python3 main.py MNIST PCA
    python3 main.py MNIST LDA
    python3 main.py MNIST Kernel_PCA