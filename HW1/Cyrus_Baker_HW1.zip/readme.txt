This program is meant to be run on the iris dataset. Because the iris dataset has no header row, appropriate row headers have been added to make indexing easier. This file will make correct calculations for any Iris dataset as long as the class column is labeled in the same way as this dataset. It would not work for other types of datasets because those datasets could have different attributes, different targets, different number of attributes, different data types, etc.

To run the iris file needs to be in the same directory as basic.py

    python3 basic.py iris.csv
